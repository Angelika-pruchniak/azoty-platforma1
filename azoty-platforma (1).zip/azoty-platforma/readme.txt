=== Azoty Farmer — Platforma Rolnicza ===
Contributors: grupaazoty
Tags: rolnictwo, platforma, nawozy, agro, farmer
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0.0
License: Proprietary

Interaktywna platforma rolnicza Grupy Azoty Puławy.

== Opis ==

Platforma Azoty Farmer to kompleksowy ekosystem dla rolników:
* Dashboard z pogodą, notowaniami MATIF/CBOT i alertami
* Moje Pola — monitoring NDVI i mapy satelitarne
* Centrum Finansowe — porównywarka banków (wzorowana na Millennium)
* Marketplace Total Farm Solution
* Barter 4.0 — giełda płodów rolnych
* ESG & Certyfikaty Węglowe
* Doradca KAM (3-poziomowy)
* Alerty Sąsiedzkie z mapą

== Instalacja ==

1. Wgraj folder `azoty-platforma` do katalogu `/wp-content/plugins/`
   LUB wgraj plik ZIP przez Panel WordPress → Wtyczki → Dodaj nową → Wgraj wtyczkę
2. Aktywuj wtyczkę w menu Wtyczki
3. Wstaw shortcode na dowolnej stronie lub wpisie:

   [azoty_platforma]

   Opcje:
   [azoty_platforma height="950"]
   [azoty_platforma height="900" width="100%"]

== Changelog ==

= 1.0.0 =
* Pierwsza wersja

