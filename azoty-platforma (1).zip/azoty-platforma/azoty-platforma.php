<?php
/**
 * Plugin Name: Azoty Farmer — Platforma Rolnicza
 * Plugin URI:  https://www.grupaazoty.com
 * Description: Interaktywna platforma rolnicza Grupy Azoty Puławy. Użyj shortcode [azoty_platforma] lub [azoty_platforma height="900"] na dowolnej stronie lub wpisie.
 * Version:     1.0.0
 * Author:      Grupa Azoty Puławy
 * Author URI:  https://www.grupaazoty.com
 * License:     Proprietary
 * Text Domain: azoty-platforma
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'AZOTY_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'AZOTY_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Shortcode: [azoty_platforma]
 * Opcje:
 *   height="850"        — wysokość iframe w pikselach (domyślnie 900)
 *   width="100%"        — szerokość (domyślnie 100%)
 *   class="moja-klasa"  — dodatkowa klasa CSS
 *
 * Przykład: [azoty_platforma height="950"]
 */
function azoty_platforma_shortcode( $atts ) {
    $atts = shortcode_atts( array(
        'height' => '900',
        'width'  => '100%',
        'class'  => '',
    ), $atts, 'azoty_platforma' );

    $height = absint( $atts['height'] );
    if ( $height < 400 ) $height = 900;
    $width  = esc_attr( $atts['width'] );
    $extra  = esc_attr( $atts['class'] );

    $src = AZOTY_PLUGIN_URL . 'app.html';

    $output  = '<div class="azoty-platforma-wrap ' . $extra . '" style="width:' . $width . ';overflow:hidden;border-radius:12px;box-shadow:0 4px 32px rgba(0,0,0,.12);">';
    $output .= '<iframe ';
    $output .= 'src="' . esc_url( $src ) . '" ';
    $output .= 'width="100%" ';
    $output .= 'height="' . $height . 'px" ';
    $output .= 'style="border:none;display:block;border-radius:12px;" ';
    $output .= 'title="Azoty Farmer — Platforma Rolnicza" ';
    $output .= 'loading="lazy" ';
    $output .= 'allowfullscreen ';
    $output .= '></iframe>';
    $output .= '</div>';

    return $output;
}
add_shortcode( 'azoty_platforma', 'azoty_platforma_shortcode' );

/**
 * Gutenberg block (opcjonalny) — wstawia shortcode jako blok HTML
 * Widoczny w edytorze jako "Azoty Platforma"
 */
function azoty_register_block() {
    if ( ! function_exists( 'register_block_type' ) ) return;
    wp_register_script(
        'azoty-block',
        AZOTY_PLUGIN_URL . 'block.js',
        array( 'wp-blocks', 'wp-element', 'wp-editor' ),
        '1.0.0'
    );
    register_block_type( 'azoty/platforma', array(
        'editor_script'   => 'azoty-block',
        'render_callback' => 'azoty_platforma_shortcode',
        'attributes'      => array(
            'height' => array( 'type' => 'string', 'default' => '900' ),
            'width'  => array( 'type' => 'string', 'default' => '100%' ),
            'class'  => array( 'type' => 'string', 'default' => '' ),
        ),
    ) );
}
add_action( 'init', 'azoty_register_block' );

/**
 * Dodaj style responsywne do front-endu
 */
function azoty_frontend_styles() {
    echo '<style>
.azoty-platforma-wrap iframe {
    min-height: 600px;
}
@media (max-width: 768px) {
    .azoty-platforma-wrap iframe {
        height: 700px !important;
    }
}
</style>';
}
add_action( 'wp_head', 'azoty_frontend_styles' );

/**
 * Link "Instrukcja" w liście wtyczek
 */
function azoty_plugin_links( $links ) {
    $links[] = '<a href="https://www.grupaazoty.com" target="_blank">Strona produktu</a>';
    $links[] = '<strong>Shortcode: [azoty_platforma]</strong>';
    return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'azoty_plugin_links' );
