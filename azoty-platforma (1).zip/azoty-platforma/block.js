(function(blocks, element, editor) {
    var el = element.createElement;
    var InspectorControls = editor.InspectorControls || (wp.blockEditor && wp.blockEditor.InspectorControls);

    blocks.registerBlockType('azoty/platforma', {
        title: 'Azoty Farmer — Platforma',
        icon: 'admin-site-alt3',
        category: 'embed',
        description: 'Wstawia interaktywną platformę rolniczą Grupy Azoty Puławy.',
        attributes: {
            height: { type: 'string', default: '900' },
            width:  { type: 'string', default: '100%' },
        },
        edit: function(props) {
            return el('div', { style: { background: '#1a2e52', borderRadius: '10px', padding: '24px', color: '#fff', textAlign: 'center' } },
                el('div', { style: { fontSize: '32px', marginBottom: '8px' } }, '🌾'),
                el('div', { style: { fontSize: '16px', fontWeight: '700', marginBottom: '4px' } }, 'Azoty Farmer — Platforma Rolnicza'),
                el('div', { style: { fontSize: '12px', opacity: '.7' } }, 'Shortcode: [azoty_platforma height="' + props.attributes.height + '"]'),
                el('div', { style: { fontSize: '11px', opacity: '.5', marginTop: '8px' } }, 'Platforma wyświetli się po opublikowaniu strony')
            );
        },
        save: function() {
            return null; // render_callback handles output
        }
    });
}(window.wp.blocks, window.wp.element, window.wp.blockEditor || window.wp.editor));
